/* Auto‑generated custom markers with white text and variable sizes */
UnminedCustomMarkers = {
  isEnabled: true,
  markers: [
    {
      x: -2898.5, z: -3469.5,
      image: "star.png", imageAnchor: [0.5,1], imageScale: 0.35,
      text: "Harlow, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 32px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -71.5, z: 98.5,
      image: "star.png", imageAnchor: [0.5,1], imageScale: 0.35,
      text: "Octavian, SK, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 32px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -5186.5, z: 4910.5,
      image: "star.png", imageAnchor: [0.5,1], imageScale: 0.35,
      text: "La Morley, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 32px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -11978, z: 15233,
      image: "star.png", imageAnchor: [0.5,1], imageScale: 0.35,
      text: "Quantum, KV", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 32px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -3347.5, z: -3939.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "North Harlow, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -2200.5, z: -4588.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Oxland, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -3417.5, z: -3363.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Saylor, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -5682.5, z: -4543.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Elowah, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -2393.5, z: -2341.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Razalia, RA, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 261.5, z: 1879.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Klaxikin, HA, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -260.5, z: -128.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Griffin, SK, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -215.5, z: 247.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Sphinx, SK, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -361.5, z: 4311.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Ruby, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 8545.5, z: -872.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Prunelle, SA", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -7293.5, z: 8614.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Malakai, KV", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -144.5, z: -2630.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Reno, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -2351.5, z: -4414.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Eizerfield, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -324.5, z: 465.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.32,
      text: "Rosewood, HV, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -2151.5, z: -3451.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Khaleesi, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -5448.5, z: -4338.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Foley, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -7664.5, z: 9929.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Lilo, KV", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 1116.5, z: 1554.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Zalex, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 1771.5, z: -929.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Valance, BN, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1824.5, z: 952.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Skyhaven, HN, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -575.5, z: 403.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Brooklyn, HP, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 197.5, z: 605.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Adaline, HV, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 106.5, z: -290.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Harlie, SK, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -517.5, z: 0.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Maria, HP, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -242.5, z: -1710.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Tayberry, SY, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -671.5, z: -3188.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Taholah, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 85.5, z: -570.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Chaseloke, HG, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -176.5, z: -1203.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Noland, HG, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -11945.5, z: -10197.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Alouette, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -4659.5, z: 5113.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Gumbo, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -5418.5, z: 4575.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Bourbon, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -3739.5, z: 4255.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "La Aurielle, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 18px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -13058, z: -11692,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Little Ellie, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -9033.5, z: -10519.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Grizzly, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -11877.5, z: -9495.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Sitkan, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -12856, z: -10095, 
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Porter, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -2577.5, z: -2509.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Raspberry, RA, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1511.5, z: -2196.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Baylie, MK, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1019.5, z: -2372.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Bells, MK, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 53.5, z: -2898.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Orla, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -8125.5, z: -2226.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Elodie, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1718.5, z: -4148.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Coralie, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -4738.5, z: -7396.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Harlen, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -2476.5, z: -3880.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Athena, JC", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 846.5, z: -1235.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Morven, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -749.5, z: 730.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Hyman, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 1709.5, z: 2136.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Facility A51, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 712.5, z: 3351.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Malani, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1036.5, z: 4473.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Damase, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 1838.5, z: 138.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Maula, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1132.5, z: 199.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Little Paws Safari, HP, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -5298, z: 5529.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Les Solènne, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 20px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",}, 
    {
      x: -5365, z: 5731,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Belle Ombre, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 2936.5, z: -620.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Lenore, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",}, 
    {
      x: 15922.5, z: -8992.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Orlaith, SA", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 22px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",}, 
    {
      x: 8511.5, z: -1149.5,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Eulaliè, SA", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 16px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -196, z: 1032,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Jackson, HV, SKY", textColor: "white",
      offsetX: 0, offsetY: 14,
      font: "bold 16px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -12, z: 1143,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Lemons, HV, SKY", textColor: "white",
      offsetX: 0, offsetY: 14,
      font: "bold 16px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 129, z: 1337,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Savia, HV, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 16px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -3170, z: 1913, 
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Selah, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 13px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 492, z: -79, 
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.28,
      text: "Xhaelis, YU, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 25px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -2917, z: -1901,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Bellamy, MK, SKY", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -8337, z: 8608,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Malu, KV", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 23px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -8157, z: 8886, 
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Lilinoe, KV", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 4157, z: 16745, 
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Cosme, KV", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 14px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: 8590, z: 21982,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "L'Eulàlia, KV", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 23px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -901, z: 2860, 
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Verdante, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 13px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1144, z: 3232,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Oliveto, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 13px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
    {
      x: -1019, z: 4028,
      image: "custom.pin.png", imageAnchor: [0.5,1], imageScale: 0.24,
      text: "Castello, VW", textColor: "white",
      offsetX: 0, offsetY: 15,
      font: "bold 13px Calibri,sans serif"
    ,
      fontShadow: true,
      fontShadowColor: "#000000",},
  ]
};