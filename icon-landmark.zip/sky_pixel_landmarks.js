/* Sky Pixel landmark markers: parks, peaks, fjords, ports, stadiums, scenic areas. */
window.SkyPixelLandmarkMarkers = {
  isEnabled: true,
  markers: [
    {
      x: -4991.5, z: -8644.5, y: -27.0,
      category: 'landmark', popupTitle: "Aeta Provincial Park", popupType: "Provincial Park",
      popupDescription: "Explore Aeta Provincial Park in the Sky Pixel Minecraft world.",
      image: "icon-park.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Aeta Provincial Park", textColor: "#9be27d",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 18px Calibri,sans-serif", labelMinZoom: 4.55
    },
    {
      x: -3853.5, z: -5492.5, y: 74.0,
      category: 'landmark', popupTitle: "Blackfall Provincial Park", popupType: "Provincial Park",
      popupDescription: "Explore Blackfall Provincial Park in the Sky Pixel Minecraft world.",
      image: "icon-park.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Blackfall Provincial Park", textColor: "#9be27d",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 18px Calibri,sans-serif", labelMinZoom: 4.55
    },
    {
      x: -13230.5, z: -22672.5, y: 144.0,
      category: 'landmark', popupTitle: "Noraker Provincial Park", popupType: "Provincial Park",
      popupDescription: "Explore Noraker Provincial Park in the Sky Pixel Minecraft world.",
      image: "icon-park.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Noraker Provincial Park", textColor: "#9be27d",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 18px Calibri,sans-serif", labelMinZoom: 4.55
    },
    {
      x: -2033.5, z: -1525.5, y: 73.0,
      category: 'landmark', popupTitle: "Mount Emma Park / Reserve", popupType: "Nature Reserve",
      popupDescription: "Explore Mount Emma Park / Reserve in the Sky Pixel Minecraft world.",
      image: "icon-park.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Mount Emma Park / Reserve", textColor: "#a8e884",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.85
    },
    {
      x: -424.5, z: 6256.5, y: 62.0,
      category: 'landmark', popupTitle: "Cayenne Canyon Provincial Park", popupType: "Provincial Park",
      popupDescription: "Explore Cayenne Canyon Provincial Park in the Sky Pixel Minecraft world.",
      image: "icon-park.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Cayenne Canyon Provincial Park", textColor: "#9be27d",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 18px Calibri,sans-serif", labelMinZoom: 4.55
    },
    {
      x: -5210.5, z: 5359.5, y: 73.0,
      category: 'landmark', popupTitle: "Bosley Bayou Nature Reserve", popupType: "Nature Reserve",
      popupDescription: "Explore Bosley Bayou Nature Reserve in the Sky Pixel Minecraft world.",
      image: "icon-park.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Bosley Bayou Nature Reserve", textColor: "#a8e884",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.85
    },
    {
      x: -9134.5, z: -6877.5, y: 63.0,
      category: 'landmark', popupTitle: "North Casific Ocean", popupType: "Ocean",
      popupDescription: "Explore North Casific Ocean in the Sky Pixel Minecraft world.",
      image: "icon-water.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "North Casific Ocean", textColor: "#7fcfff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 20px Calibri,sans-serif", labelMinZoom: 3.55
    },
    {
      x: -10746.5, z: 12811.5, y: 63.0,
      category: 'landmark', popupTitle: "South Casific Ocean", popupType: "Ocean",
      popupDescription: "Explore South Casific Ocean in the Sky Pixel Minecraft world.",
      image: "icon-water.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "South Casific Ocean", textColor: "#7fcfff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 20px Calibri,sans-serif", labelMinZoom: 3.55
    },
    {
      x: -4453.5, z: -4357.5, y: 214.0,
      category: 'landmark', popupTitle: "Lower North Coast Mountains", popupType: "Mountain Range",
      popupDescription: "Explore Lower North Coast Mountains in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "Lower North Coast Mountains", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 3.95
    },
    {
      x: -9190.5, z: -11916.5, y: -21.0,
      category: 'landmark', popupTitle: "Upper North Coast Mountains", popupType: "Mountain Range",
      popupDescription: "Explore Upper North Coast Mountains in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "Upper North Coast Mountains", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 3.95
    },
    {
      x: -12753.5, z: -17711.5, y: 84.0,
      category: 'landmark', popupTitle: "Alyeska Ranges", popupType: "Mountain Range",
      popupDescription: "Explore Alyeska Ranges in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "Alyeska Ranges", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 3.95
    },
    {
      x: -16421.5, z: -16210.5, y: 63.0,
      category: 'landmark', popupTitle: "South La Baie d'Ellie Fjord", popupType: "Fjord / Inlet",
      popupDescription: "Explore South La Baie d'Ellie Fjord in the Sky Pixel Minecraft world.",
      image: "icon-water.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "South La Baie d'Ellie Fjord", textColor: "#73c9ff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 4.05
    },
    {
      x: -15701.5, z: -19527.5, y: 63.0,
      category: 'landmark', popupTitle: "North La Baie d'Ellie Fjord", popupType: "Fjord / Inlet",
      popupDescription: "Explore North La Baie d'Ellie Fjord in the Sky Pixel Minecraft world.",
      image: "icon-water.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "North La Baie d'Ellie Fjord", textColor: "#73c9ff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 4.05
    },
    {
      x: -15344.5, z: -15758.5, y: 63.0,
      category: 'landmark', popupTitle: "Ellowetta Fjord", popupType: "Fjord / Inlet",
      popupDescription: "Explore Ellowetta Fjord in the Sky Pixel Minecraft world.",
      image: "icon-water.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Ellowetta Fjord", textColor: "#73c9ff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 4.05
    },
    {
      x: -11461.5, z: -13054.5, y: 63.0,
      category: 'landmark', popupTitle: "Lullaby Fjord / Inlet", popupType: "Fjord / Inlet",
      popupDescription: "Explore Lullaby Fjord / Inlet in the Sky Pixel Minecraft world.",
      image: "icon-water.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Lullaby Fjord / Inlet", textColor: "#73c9ff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 4.05
    },
    {
      x: -2902.5, z: -2841.5, y: 63.0,
      category: 'landmark', popupTitle: "Marie Inlet", popupType: "Fjord / Inlet",
      popupDescription: "Explore Marie Inlet in the Sky Pixel Minecraft world.",
      image: "icon-water.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Marie Inlet", textColor: "#73c9ff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 4.05
    },
    {
      x: -1679.5, z: -1560.5, y: 217.0,
      category: 'landmark', popupTitle: "Mount Emma", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Emma in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Emma", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -2320.5, z: -3152.5, y: 312.0,
      category: 'landmark', popupTitle: "Mount Rayna", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Rayna in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Rayna", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -2224.5, z: -3284.5, y: 240.0,
      category: 'landmark', popupTitle: "Mount Khaleesi", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Khaleesi in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Khaleesi", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -2422.5, z: -3349.5, y: 224.0,
      category: 'landmark', popupTitle: "Mount Emerald", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Emerald in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Emerald", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -3193.5, z: -3314.5, y: 214.0,
      category: 'landmark', popupTitle: "Mount Harlow", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Harlow in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Harlow", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -3738.5, z: -3965.5, y: 165.0,
      category: 'landmark', popupTitle: "Saylor's Castle", popupType: "Landmark",
      popupDescription: "Explore Saylor's Castle in the Sky Pixel Minecraft world.",
      image: "icon-landmark.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Saylor's Castle", textColor: "#e2cf98",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 15px Calibri,sans-serif", labelMinZoom: 5.2
    },
    {
      x: -5000.5, z: -5330.5, y: 444.0,
      category: 'landmark', popupTitle: "Mount Cambrie", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Cambrie in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Cambrie", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -5224.5, z: -6533.5, y: 316.0,
      category: 'landmark', popupTitle: "Mount Porter", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Porter in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Porter", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -3753.5, z: -6033.5, y: 312.0,
      category: 'landmark', popupTitle: "Mount Blackfall", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Blackfall in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Blackfall", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -3231.5, z: -6772.5, y: 292.0,
      category: 'landmark', popupTitle: "Mount Bellaquah", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Bellaquah in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Bellaquah", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -6450.5, z: -8580.5, y: 308.0,
      category: 'landmark', popupTitle: "South Mount Ellie", popupType: "Mountain Peak",
      popupDescription: "Explore South Mount Ellie in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "South Mount Ellie", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -6526.5, z: -9859.5, y: 241.0,
      category: 'landmark', popupTitle: "North Mount Ellie", popupType: "Mountain Peak",
      popupDescription: "Explore North Mount Ellie in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "North Mount Ellie", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -13465.5, z: -22333.5, y: 500.0,
      category: 'landmark', popupTitle: "Mount Noraker", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Noraker in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Noraker", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -13738.5, z: -20076.5, y: 444.0,
      category: 'landmark', popupTitle: "Mount Sok'aan", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Sok'aan in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Sok'aan", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -12172.5, z: -18080.5, y: 497.0,
      category: 'landmark', popupTitle: "Mount Kimura", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Kimura in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Kimura", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -693.5, z: -2246.5, y: 170.0,
      category: 'landmark', popupTitle: "Mount Toblerone", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Toblerone in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Toblerone", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -1623.5, z: -569.5, y: 142.0,
      category: 'landmark', popupTitle: "Mount Jessika", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Jessika in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Jessika", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -1644.5, z: -1116.5, y: 146.0,
      category: 'landmark', popupTitle: "South Lofall Mountains", popupType: "Mountain Range",
      popupDescription: "Explore South Lofall Mountains in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "South Lofall Mountains", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 3.95
    },
    {
      x: -2807.5, z: -3242.5, y: 177.0,
      category: 'landmark', popupTitle: "North Lofall Mountains", popupType: "Mountain Range",
      popupDescription: "Explore North Lofall Mountains in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "North Lofall Mountains", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 3.95
    },
    {
      x: -5568.5, z: -5475.5, y: 313.0,
      category: 'landmark', popupTitle: "Mount Umpqua", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Umpqua in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Umpqua", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -8509.5, z: -9940.5, y: 284.0,
      category: 'landmark', popupTitle: "Mount Lillooet", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Lillooet in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Lillooet", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -12320.5, z: -13330.5, y: 147.0,
      category: 'landmark', popupTitle: "Kusuah Island", popupType: "Island",
      popupDescription: "Explore Kusuah Island in the Sky Pixel Minecraft world.",
      image: "icon-island.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Kusuah Island", textColor: "#7fe4d2",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.75
    },
    {
      x: -8588.5, z: 8814.5, y: 166.0,
      category: 'landmark', popupTitle: "Raymon Island", popupType: "Island",
      popupDescription: "Explore Raymon Island in the Sky Pixel Minecraft world.",
      image: "icon-island.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Raymon Island", textColor: "#7fe4d2",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.75
    },
    {
      x: -5786.5, z: 7969.5, y: 371.0,
      category: 'landmark', popupTitle: "Maia Island", popupType: "Island",
      popupDescription: "Explore Maia Island in the Sky Pixel Minecraft world.",
      image: "icon-island.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Maia Island", textColor: "#7fe4d2",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.75
    },
    {
      x: -7715.5, z: 9164.5, y: 63.0,
      category: 'landmark', popupTitle: "Kealoha Isles", popupType: "Island",
      popupDescription: "Explore Kealoha Isles in the Sky Pixel Minecraft world.",
      image: "icon-island.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Kealoha Isles", textColor: "#7fe4d2",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.75
    },
    {
      x: -8882.5, z: 10276.5, y: 432.0,
      category: 'landmark', popupTitle: "Mount Kailani", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Kailani in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Kailani", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -7051.5, z: 10865.5, y: 350.0,
      category: 'landmark', popupTitle: "Puanna Provincial Park / Island", popupType: "Island",
      popupDescription: "Explore Puanna Provincial Park / Island in the Sky Pixel Minecraft world.",
      image: "icon-island.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Puanna Provincial Park / Island", textColor: "#7fe4d2",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.75
    },
    {
      x: 1230.5, z: 11420.5, y: 168.0,
      category: 'landmark', popupTitle: "North Serra-Dor Mountains", popupType: "Mountain Range",
      popupDescription: "Explore North Serra-Dor Mountains in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "North Serra-Dor Mountains", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 3.95
    },
    {
      x: 6803.5, z: 20386.5, y: 178.0,
      category: 'landmark', popupTitle: "South Serra-Dor Mountains", popupType: "Mountain Range",
      popupDescription: "Explore South Serra-Dor Mountains in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.22,
      text: "South Serra-Dor Mountains", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 18px Calibri,sans-serif", labelMinZoom: 3.95
    },
    {
      x: 104.5, z: 7453.5, y: 69.0,
      category: 'landmark', popupTitle: "Shaili Desert / Basin Overlook", popupType: "Scenic Area",
      popupDescription: "Explore Shaili Desert / Basin Overlook in the Sky Pixel Minecraft world.",
      image: "icon-scenic.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Shaili Desert / Basin Overlook", textColor: "#ffdb82",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 15px Calibri,sans-serif", labelMinZoom: 5.0
    },
    {
      x: -1107.5, z: -1799.5, y: 69.0,
      category: 'landmark', popupTitle: "Shannan Forest Reserve", popupType: "Nature Reserve",
      popupDescription: "Explore Shannan Forest Reserve in the Sky Pixel Minecraft world.",
      image: "icon-park.svg", imageAnchor: [0.5, 1], imageScale: 0.3,
      text: "Shannan Forest Reserve", textColor: "#a8e884",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 16px Calibri,sans-serif", labelMinZoom: 4.85
    },
    {
      x: 8330.5, z: -354.5, y: 246.0,
      category: 'landmark', popupTitle: "Mount Monica", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Monica in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Monica", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -1789.5, z: -2172.5, y: 199.0,
      category: 'landmark', popupTitle: "Mount Sherida", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Sherida in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Sherida", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -1977.5, z: -2460.5, y: 196.0,
      category: 'landmark', popupTitle: "Mount Sammish", popupType: "Mountain Peak",
      popupDescription: "Explore Mount Sammish in the Sky Pixel Minecraft world.",
      image: "icon-mountain.svg", imageAnchor: [0.5, 1], imageScale: 0.24,
      text: "Mount Sammish", textColor: "#ffffff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "italic 16px Calibri,sans-serif", labelMinZoom: 5.1
    },
    {
      x: -3168.5, z: -2808.5, y: 71.0,
      category: 'landmark', popupTitle: "Port of Razalia", popupType: "Port / Harbor",
      popupDescription: "Explore Port of Razalia in the Sky Pixel Minecraft world.",
      image: "icon-port.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Port of Razalia", textColor: "#aeeaff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.25
    },
    {
      x: -3900.5, z: -3251.5, y: 63.0,
      category: 'landmark', popupTitle: "Port of Saylor / Harlow", popupType: "Port / Harbor",
      popupDescription: "Explore Port of Saylor / Harlow in the Sky Pixel Minecraft world.",
      image: "icon-port.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Port of Saylor / Harlow", textColor: "#aeeaff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.25
    },
    {
      x: -6076.5, z: -4805.5, y: 65.0,
      category: 'landmark', popupTitle: "Port of Elowah", popupType: "Port / Harbor",
      popupDescription: "Explore Port of Elowah in the Sky Pixel Minecraft world.",
      image: "icon-port.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Port of Elowah", textColor: "#aeeaff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.25
    },
    {
      x: -12134.5, z: 15561.5, y: 63.0,
      category: 'landmark', popupTitle: "Port of Quantum", popupType: "Port / Harbor",
      popupDescription: "Explore Port of Quantum in the Sky Pixel Minecraft world.",
      image: "icon-port.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Port of Quantum", textColor: "#aeeaff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.25
    },
    {
      x: -7478.5, z: 8275.5, y: 64.0,
      category: 'landmark', popupTitle: "Port of North Malakai", popupType: "Port / Harbor",
      popupDescription: "Explore Port of North Malakai in the Sky Pixel Minecraft world.",
      image: "icon-port.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Port of North Malakai", textColor: "#aeeaff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.25
    },
    {
      x: -11731.5, z: -9681.5, y: 63.0,
      category: 'landmark', popupTitle: "Sitkan Harbor", popupType: "Port / Harbor",
      popupDescription: "Explore Sitkan Harbor in the Sky Pixel Minecraft world.",
      image: "icon-port.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Sitkan Harbor", textColor: "#aeeaff",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.25
    },
    {
      x: -640.5, z: -296.5, y: 118.0,
      category: 'landmark', popupTitle: "Octavian Night Raven Stadium", popupType: "Stadium",
      popupDescription: "Explore Octavian Night Raven Stadium in the Sky Pixel Minecraft world.",
      image: "icon-stadium.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Octavian Night Raven Stadium", textColor: "#ffbd73",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.35
    },
    {
      x: -4077.5, z: -3561.5, y: 127.0,
      category: 'landmark', popupTitle: "Harlow Grizzlies Stadium", popupType: "Stadium",
      popupDescription: "Explore Harlow Grizzlies Stadium in the Sky Pixel Minecraft world.",
      image: "icon-stadium.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Harlow Grizzlies Stadium", textColor: "#ffbd73",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.35
    },
    {
      x: -5032.5, z: 5170.5, y: 65.0,
      category: 'landmark', popupTitle: "La Morley Gators Stadium", popupType: "Stadium",
      popupDescription: "Explore La Morley Gators Stadium in the Sky Pixel Minecraft world.",
      image: "icon-stadium.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "La Morley Gators Stadium", textColor: "#ffbd73",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.35
    },
    {
      x: 8378.5, z: -1216.5, y: 112.0,
      category: 'landmark', popupTitle: "Prunelle Hydras Stadium", popupType: "Stadium",
      popupDescription: "Explore Prunelle Hydras Stadium in the Sky Pixel Minecraft world.",
      image: "icon-stadium.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Prunelle Hydras Stadium", textColor: "#ffbd73",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.35
    },
    {
      x: -11951.5, z: 15022.5, y: 21.0,
      category: 'landmark', popupTitle: "Quantum Dragons Stadium", popupType: "Stadium",
      popupDescription: "Explore Quantum Dragons Stadium in the Sky Pixel Minecraft world.",
      image: "icon-stadium.svg", imageAnchor: [0.5, 1], imageScale: 0.23,
      text: "Quantum Dragons Stadium", textColor: "#ffbd73",
      textStrokeColor: 'rgba(0,0,0,0.92)', textStrokeWidth: 4,
      offsetX: 0, offsetY: 16,
      font: "bold 14px Calibri,sans-serif", labelMinZoom: 5.35
    },
  ]
};
